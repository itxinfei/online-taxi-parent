package com.online.taxi.demo.taxi.common.constant;

public class IdentityConstant {
	
	public static final int PASSENGER = 1;
	
	public static final int DRIVER = 2;
	
}
