self.__precacheManifest = [
  {
    "revision": "95f239055d552e5e155b",
    "url": "/css/app.8279e03a.css"
  },
  {
    "revision": "95f239055d552e5e155b",
    "url": "/js/app.f4946f73.js"
  },
  {
    "revision": "5a4ae201ba5845898ea9",
    "url": "/js/chunk-vendors.e63eea42.js"
  },
  {
    "revision": "e142b3f081fefbcffcd4f75c496f2dbd",
    "url": "/img/iconfont.e142b3f0.svg"
  },
  {
    "revision": "922feaef991c8e2cb53ef9c88e02f1e5",
    "url": "/index.html"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
];